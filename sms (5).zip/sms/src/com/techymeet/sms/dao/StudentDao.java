package com.techymeet.sms.dao;

import java.util.ArrayList;

import com.techymeet.sms.bo.StudentBo;

public interface StudentDao {
	
	int createAccount(StudentBo studentBo);
	
	ArrayList<StudentBo> listStudents();
	
	StudentBo viewStudent(int studentId);
	
	ArrayList<StudentBo> searchStudent(StudentBo stuBo);
	
	int editStudent(StudentBo studentBo);
	
	int deleteStudent(int studentId);                                                     

}
