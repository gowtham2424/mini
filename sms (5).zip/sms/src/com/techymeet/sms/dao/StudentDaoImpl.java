package com.techymeet.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.techymeet.sms.bo.StudentBo;
import com.techymeet.sms.utils.DataBaseConnection;

public class StudentDaoImpl implements StudentDao{

	@Override
	public int createAccount(StudentBo studentBo) {
		
		int status=0;
		try {
			Connection con=DataBaseConnection.createConnection();
			String query="insert into student(first_name,last_name,email_address,password,confirm_password,mobile_number,date_of_birth,address,city,state,country) values(?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, studentBo.getFirstName());
			ps.setString(2, studentBo.getLastName());
			ps.setString(3, studentBo.getEmailAddress());
			ps.setString(4, studentBo.getPassword());
			ps.setString(5, studentBo.getConfirmPassword());
			ps.setLong(6, studentBo.getMobileNumber());
			ps.setString(7, studentBo.getDateOfBirth());
			ps.setString(8, studentBo.getAddress());
			ps.setString(9, studentBo.getCity());
			ps.setString(10, studentBo.getState());
			ps.setString(11, studentBo.getCountry());
			
			status=ps.executeUpdate();
			
			con.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return status;
	}

	@Override
	public ArrayList<StudentBo> listStudents() {
		ArrayList<StudentBo> studentList=new ArrayList<>();
		
		try {
			Connection con=DataBaseConnection.createConnection();
			String query="select * from student";
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				StudentBo studentBo=new StudentBo();
				
				studentBo.setStudentId(rs.getInt(1));
				studentBo.setFirstName(rs.getString(2));
				studentBo.setLastName(rs.getString(2));
				studentBo.setEmailAddress(rs.getString(4));
				studentBo.setPassword(rs.getString(5));
				studentBo.setConfirmPassword(rs.getString(6));
				studentBo.setMobileNumber(rs.getLong(7));
				studentBo.setDateOfBirth(rs.getString(8));
				studentBo.setAddress(rs.getString(9));
				studentBo.setCity(rs.getString(10));
				studentBo.setState(rs.getString(11));
				studentBo.setCountry(rs.getString(12));
				
				studentList.add(studentBo);
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return studentList;
	}

	@Override
	public StudentBo viewStudent(int studentId) {
		StudentBo studentBo=new StudentBo();
		try {
			Connection con=DataBaseConnection.createConnection();
			String query="Select * from student where student_Id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, studentId);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				studentBo.setStudentId(rs.getInt(1));
				studentBo.setFirstName(rs.getString(2));
				studentBo.setLastName(rs.getString(3));
				studentBo.setEmailAddress(rs.getString(4));
				studentBo.setPassword(rs.getString(5));
				studentBo.setConfirmPassword(rs.getString(6));
				studentBo.setMobileNumber(rs.getLong(7));
				studentBo.setDateOfBirth(rs.getString(8));
				studentBo.setAddress(rs.getString(9));
				studentBo.setCity(rs.getString(10));
				studentBo.setState(rs.getString(11));
				studentBo.setCountry(rs.getString(12));
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return studentBo;
	}

	@Override
	public ArrayList<StudentBo> searchStudent(StudentBo stuBo) {
		ArrayList<StudentBo> studentList=new ArrayList<>();
		try {
			Connection con=DataBaseConnection.createConnection();
			
			String query="Select * from student where first_name like ?";
			//String query="Select * from student where first_name=?";
			
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, "%" +stuBo.getFirstName()+ "%");
			//ps.setString(1, stuBo.getFirstName());
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				StudentBo studBo=new StudentBo();
				
				studBo.setStudentId(rs.getInt(1));
				studBo.setFirstName(rs.getString(2));
				studBo.setLastName(rs.getString(3));
				studBo.setEmailAddress(rs.getString(4));
				studBo.setPassword(rs.getString(5));
				studBo.setConfirmPassword(rs.getString(6));
				studBo.setMobileNumber(rs.getLong(7));
				studBo.setDateOfBirth(rs.getString(8));
				studBo.setAddress(rs.getString(9));
				studBo.setCity(rs.getString(10));
				studBo.setState(rs.getString(11));
				studBo.setCountry(rs.getString(12));
				
				studentList.add(studBo);
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return studentList;
	}

	@Override
	public int editStudent(StudentBo studentBo) {
		int status=0;
		try {
			Connection con=DataBaseConnection.createConnection();
			String query="update student set first_name=?,last_name=?,email_address=?,password=?,confirm_password=?,mobile_number=?,date_of_birth=?,address=?,city=?,state=?,country=? where student_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, studentBo.getFirstName());
			ps.setString(2, studentBo.getLastName());
			ps.setString(3, studentBo.getEmailAddress());
			ps.setString(4, studentBo.getPassword());
			ps.setString(5, studentBo.getConfirmPassword());
			ps.setLong(6, studentBo.getMobileNumber());
			ps.setString(7, studentBo.getDateOfBirth());
			ps.setString(8, studentBo.getAddress());
			ps.setString(9, studentBo.getCity());
			ps.setString(10, studentBo.getState());
			ps.setString(11, studentBo.getCountry());
			ps.setInt(12, studentBo.getStudentId());
			
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return status;
	}

	@Override
	public int deleteStudent(int studentId) {
		int status=0;
		try {
			Connection con=DataBaseConnection.createConnection();
			String query="delete from student where student_id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, studentId);
			status=ps.executeUpdate();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return status;
	}
}
