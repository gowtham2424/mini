package com.techymeet.sms.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.techymeet.sms.bo.StudentBo;
import com.techymeet.sms.dao.StudentDao;
import com.techymeet.sms.dao.StudentDaoImpl;

public class StudentServiceImpl implements StudentService{
	List<StudentBo> studentList=new ArrayList<>();
	
	StudentDao studentDao=new StudentDaoImpl();

	@Override
	public void createStudent() {
		Scanner scannerObj=new Scanner(System.in);
		StudentBo studentBo=new StudentBo();
		
		StudentDao studentDao=new StudentDaoImpl();
		
		System.out.println("Enter student id: ");
		int studentId=0;
		boolean studentIdStatus=true;
		try {
			while(studentIdStatus) {
				studentId=scannerObj.nextInt();
				if(0<studentId) {
					studentBo.setStudentId(studentId);
					studentIdStatus=false;			
				}else {
					System.out.println("Please enter valid student id: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		scannerObj.nextLine();
		
		System.out.println("Enter First Name: ");
		String firstName=null;
		boolean firstNameStatus=true;
		try {
			while(firstNameStatus) {
				firstName=scannerObj.nextLine();
				if(!firstName.isEmpty()) {
					studentBo.setFirstName(firstName);
					firstNameStatus=false;			
				}else {
					System.out.println("Please enter valid First Name: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Last Name: ");
		String lastName=null;
		boolean lastNameStatus=true;
		try {
			while(lastNameStatus) {
				lastName=scannerObj.nextLine();
				if(!lastName.isEmpty()) {
					studentBo.setLastName(lastName);
					lastNameStatus=false;			
				}else {
					System.out.println("Please enter valid Last Name: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Email Address: ");
		String emailAddress=null;
		boolean emailAddressStatus=true;
		try {
			while(emailAddressStatus) {
				emailAddress=scannerObj.nextLine();
				if(!emailAddress.isEmpty()) {
					studentBo.setEmailAddress(emailAddress);
					emailAddressStatus=false;			
				}else {
					System.out.println("Please enter valid Email Address: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Password: ");
		String password=null;
		boolean passwordStatus=true;
		try {
			while(passwordStatus) {
				password=scannerObj.nextLine();
				if(!password.isEmpty()) {
					studentBo.setPassword(password);
					passwordStatus=false;			
				}else {
					System.out.println("Please enter valid Password: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Confirm Password: ");
		String confirmPassword=null;
		boolean confirmPasswordStatus=true;
		try {
			while(confirmPasswordStatus) {
				confirmPassword=scannerObj.nextLine();
				if(!confirmPassword.isEmpty()) {
					studentBo.setConfirmPassword(confirmPassword);
					confirmPasswordStatus=false;			
				}else {
					System.out.println("Please enter valid Confirm Password: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Mobile Number: ");
		long mobileNumber=0;
		boolean mobileNumberStatus=true;
		try {
			while(mobileNumberStatus) {
				mobileNumber=scannerObj.nextLong();
				if(0<mobileNumber) {
					studentBo.setMobileNumber(mobileNumber);
					mobileNumberStatus=false;			
				}else {
					System.out.println("Please enter valid Mobile Number: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		scannerObj.nextLine();
		
		System.out.println("Enter Date Of Birth: ");
		String dateOfBirth=null;
		boolean dateOfBirthStatus=true;
		try {
			while(dateOfBirthStatus) {
				dateOfBirth=scannerObj.nextLine();
				if(!dateOfBirth.isEmpty()) {
					studentBo.setDateOfBirth(dateOfBirth);
					dateOfBirthStatus=false;			
				}else {
					System.out.println("Please enter valid Date Of Birth: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		System.out.println("Enter Address: ");
		String address=null;
		boolean addressStatus=true;
		try {
			while(addressStatus) {
				address=scannerObj.nextLine();
				if(!address.isEmpty()) {
					studentBo.setAddress(address);
					addressStatus=false;			
				}else {
					System.out.println("Please enter valid Address: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter City: ");
		String city=null;
		boolean cityStatus=true;
		try {
			while(cityStatus) {
				city=scannerObj.nextLine();
				if(!city.isEmpty()) {
					studentBo.setCity(city);
					cityStatus=false;			
				}else {
					System.out.println("Please enter valid City: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter State: ");
		String state=null;
		boolean stateStatus=true;
		try {
			while(stateStatus) {
				state=scannerObj.nextLine();
				if(!state.isEmpty()) {
					studentBo.setState(state);
					stateStatus=false;			
				}else {
					System.out.println("Please enter valid  State: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Enter Country: ");
		String country=null;
		boolean countryStatus=true;
		try {
			while(countryStatus) {
				country=scannerObj.nextLine();
				if(!country.isEmpty()) {
					studentBo.setCountry(country);
					countryStatus=false;			
				}else {
					System.out.println("Please enter valid  Country: ");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		//studentList.add(studentBo);
		
		int status=studentDao.createAccount(studentBo);
		if(0 < status) {
			System.out.println("Student Account created successfully...");
		}else {
			System.out.println("Student account creation failed!!!");
		}
		
		//System.out.println("Student Account has been created successfully...");
		//System.out.println("Redirect into login..");
		//login(studentBo.getEmailAddress(), studentBo.getPassword());
	}
	
	@Override
	public void login(String emailId, String pass) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Welcome to Login...");
		String emailId2=null;
		String pass2=null;
		
		try {
			System.out.println("Please enter your Email Address: ");
			boolean emailAddressFlag=true;
			while(emailAddressFlag) {
				emailId2=scan.nextLine();
				if(null!=emailId2 && !emailId2.isEmpty()) {
					emailAddressFlag=false;
				}
			}
			
			System.out.println("Please enter your Password: ");
			boolean passwordFlag=true;
			while(passwordFlag) {
				pass2=scan.nextLine();
				if(null!=pass2 && !pass2.isEmpty()) {
					passwordFlag=false;
				}
			}
			
			if(emailId.equals(emailId2) && pass.equals(pass2)) {
				System.out.println("You have successfully Login...");
			}else {
				System.out.println("Please check your EmailAddress and Password...!");
			}
	
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
	
	@Override
	public void listStudent() {
		
		Scanner sc=new Scanner(System.in);
		StudentBo studentBo=new StudentBo();
		
		ArrayList<StudentBo> studentList=studentDao.listStudents();
		System.out.println("OverAll Student List: ");
		System.out.println();
		
		for(StudentBo student:studentList) {
			System.out.println("Student Id: "+student.getStudentId());
			System.out.println("First Name: "+student.getFirstName());
			System.out.println("Last Name: "+student.getLastName());
			System.out.println("Email Address: "+student.getEmailAddress());
			System.out.println("Password: "+student.getPassword());
			System.out.println("Confirm Password: "+student.getConfirmPassword());
			System.out.println("Mobile Number: "+student.getMobileNumber());
			System.out.println("Date Of Birth: "+student.getDateOfBirth());
			System.out.println("Address: "+student.getAddress());
			System.out.println("City: "+student.getCity());
			System.out.println("State: "+student.getState());
			System.out.println("Country: "+student.getCountry());
			
			System.out.println();
		}
		System.out.println();
	}


	@Override
	public void updateStudent() {
		Scanner scannerObj=new Scanner(System.in);
		StudentBo studentBo=new StudentBo();
		
		viewStudent();
		
		System.out.println("...Welcome to Edit Student...");
		System.out.println("Please enter your Student Id to Update: ");
		int editStudentId=scannerObj.nextInt();
				
				System.out.println("Enter student id: ");
				int studentId=0;
				boolean studentIdStatus=true;
				try {
					while(studentIdStatus) {
						studentId=scannerObj.nextInt();
						if(0<studentId) {
							studentBo.setStudentId(studentId);
							studentIdStatus=false;			
						}else {
							System.out.println("Please enter valid student id: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				scannerObj.nextLine();
				
				System.out.println("Enter First Name: ");
				String firstName=null;
				boolean firstNameStatus=true;
				try {
					while(firstNameStatus) {
						firstName=scannerObj.nextLine();
						if(!firstName.isEmpty()) {
							studentBo.setFirstName(firstName);
							firstNameStatus=false;			
						}else {
							System.out.println("Please enter valid First Name: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Last Name: ");
				String lastName=null;
				boolean lastNameStatus=true;
				try {
					while(lastNameStatus) {
						lastName=scannerObj.nextLine();
						if(!lastName.isEmpty()) {
							studentBo.setLastName(lastName);
							lastNameStatus=false;			
						}else {
							System.out.println("Please enter valid Last Name: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Email Address: ");
				String emailAddress=null;
				boolean emailAddressStatus=true;
				try {
					while(emailAddressStatus) {
						emailAddress=scannerObj.nextLine();
						if(!emailAddress.isEmpty()) {
							studentBo.setEmailAddress(emailAddress);
							emailAddressStatus=false;			
						}else {
							System.out.println("Please enter valid Email Address: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Password: ");
				String password=null;
				boolean passwordStatus=true;
				try {
					while(passwordStatus) {
						password=scannerObj.nextLine();
						if(!password.isEmpty()) {
							studentBo.setPassword(password);
							passwordStatus=false;			
						}else {
							System.out.println("Please enter valid Password: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Confirm Password: ");
				String confirmPassword=null;
				boolean confirmPasswordStatus=true;
				try {
					while(confirmPasswordStatus) {
						confirmPassword=scannerObj.nextLine();
						if(!confirmPassword.isEmpty()) {
							studentBo.setConfirmPassword(confirmPassword);
							confirmPasswordStatus=false;			
						}else {
							System.out.println("Please enter valid Confirm Password: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Mobile Number: ");
				long mobileNumber=0;
				boolean mobileNumberStatus=true;
				try {
					while(mobileNumberStatus) {
						mobileNumber=scannerObj.nextLong();
						if(0<mobileNumber) {
							studentBo.setMobileNumber(mobileNumber);
							mobileNumberStatus=false;			
						}else {
							System.out.println("Please enter valid Mobile Number: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				scannerObj.nextLine();
				
				System.out.println("Enter Date Of Birth: ");
				String dateOfBirth=null;
				boolean dateOfBirthStatus=true;
				try {
					while(dateOfBirthStatus) {
						dateOfBirth=scannerObj.nextLine();
						if(!dateOfBirth.isEmpty()) {
							studentBo.setDateOfBirth(dateOfBirth);
							dateOfBirthStatus=false;			
						}else {
							System.out.println("Please enter valid Date Of Birth: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				
				System.out.println("Enter Address: ");
				String address=null;
				boolean addressStatus=true;
				try {
					while(addressStatus) {
						address=scannerObj.nextLine();
						if(!address.isEmpty()) {
							studentBo.setAddress(address);
							addressStatus=false;			
						}else {
							System.out.println("Please enter valid Address: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter City: ");
				String city=null;
				boolean cityStatus=true;
				try {
					while(cityStatus) {
						city=scannerObj.nextLine();
						if(!city.isEmpty()) {
							studentBo.setCity(city);
							cityStatus=false;			
						}else {
							System.out.println("Please enter valid City: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter State: ");
				String state=null;
				boolean stateStatus=true;
				try {
					while(stateStatus) {
						state=scannerObj.nextLine();
						if(!state.isEmpty()) {
							studentBo.setState(state);
							stateStatus=false;			
						}else {
							System.out.println("Please enter valid  State: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				System.out.println("Enter Country: ");
				String country=null;
				boolean countryStatus=true;
				try {
					while(countryStatus) {
						country=scannerObj.nextLine();
						if(!country.isEmpty()) {
							studentBo.setCountry(country);
							countryStatus=false;			
						}else {
							System.out.println("Please enter valid  Country: ");
						}
					}
				}catch(Exception e) {
					System.out.println(e);
				}
				
				//if(null!=studentBo) {
					//System.out.println("Student has been Edited successfully...");
					//int indexNum=editStudentId-1;
					//studentList.set(indexNum, studentBo);
				
				int status=studentDao.editStudent(studentBo);
				if(0 < status) {
					System.out.println("Updated Successfully...");
				}else {
					System.out.println("Update failed!!!");
				}
	}

	
	@Override
	public void viewStudent() {
		Scanner sc=new Scanner(System.in);
		StudentBo studentBo=new StudentBo();
		
		System.out.println("...Welcome to View Student Details...");
		System.out.println("Please Enter Student Id: ");
		int studentId=sc.nextInt();
		studentBo=studentDao.viewStudent(studentId);
		
		if(0 < studentBo.getStudentId()) {
			System.out.println("Student Id: "+studentBo.getStudentId());
			System.out.println("First Name: "+studentBo.getFirstName());
			System.out.println("Last Name: "+studentBo.getLastName());
			System.out.println("Email Address: "+studentBo.getEmailAddress());
			System.out.println("Password: "+studentBo.getPassword());
			System.out.println("Confirm Password: "+studentBo.getConfirmPassword());
			System.out.println("Mobile Number: "+studentBo.getMobileNumber());
			System.out.println("Date Of Birth: "+studentBo.getDateOfBirth());
			System.out.println("Address: "+studentBo.getAddress());
			System.out.println("City: "+studentBo.getCity());
			System.out.println("State: "+studentBo.getState());
			System.out.println("Country: "+studentBo.getCountry());
		
		}else {
			System.out.println("Please enter valid Student Id!!!");
		}
	}

	@Override
	public void deleteStudent() {
		Scanner scannerObj=new Scanner(System.in);
		System.out.println("...Welcome to Delete student...");
		System.out.println("Please Enter Student Id: ");
		int studentId=scannerObj.nextInt();
		int status=studentDao.deleteStudent(studentId);
		
		if(0 < status) {
			System.out.println("Student Account has been Deleted Successfully...");
		}else {
			System.out.println("Student account can not be deleted!!!");
		}
	}

	@Override
	public void searchStudent() {
		System.out.println("...Welcome to Search Student Details...");
		System.out.println("Please Enter Student First Name: ");
		
		Scanner scannerObj=new Scanner(System.in);
		StudentBo stuBo=new StudentBo();
		String firstName=null;
		Boolean nameStatus=true;
		try {
			while(nameStatus) {
				firstName=scannerObj.nextLine();
				if(!firstName.isEmpty()) {
					stuBo.setFirstName(firstName);
					nameStatus=false;
				}else {
					System.out.println("Please enter valid Student First Name!!!");
				}
			}
		}catch(Exception e) {
				e.printStackTrace();
		}
		ArrayList<StudentBo> studentBoList=studentDao.searchStudent(stuBo);
		for(StudentBo student:studentBoList) {
			System.out.println("Student Id: "+student.getStudentId());
			System.out.println("First Name: "+student.getFirstName());
			System.out.println("Last Name: "+student.getLastName());
			System.out.println("Email Address: "+student.getEmailAddress());
			System.out.println("Password: "+student.getPassword());
			System.out.println("Confirm Password: "+student.getConfirmPassword());
			System.out.println("Mobile Number: "+student.getMobileNumber());
			System.out.println("Date Of Birth: "+student.getDateOfBirth());
			System.out.println("Address: "+student.getAddress());
			System.out.println("City: "+student.getCity());
			System.out.println("State: "+student.getState());
			System.out.println("Country: "+student.getCountry());
		}
	}
}

