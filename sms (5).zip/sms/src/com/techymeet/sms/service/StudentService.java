package com.techymeet.sms.service;

public interface StudentService {
	void createStudent();
	void login(String emailId, String pass);
	void listStudent();
	void updateStudent();
	void viewStudent();
	void deleteStudent();
	void searchStudent();
	

}
