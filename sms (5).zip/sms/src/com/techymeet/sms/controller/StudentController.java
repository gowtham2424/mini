package com.techymeet.sms.controller;

import java.util.Scanner;

import com.techymeet.sms.service.StudentService;
import com.techymeet.sms.service.StudentServiceImpl;

public class StudentController {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		introduction();
		
		StudentService studentService=new StudentServiceImpl();
		boolean status=true;
		while(status) {
			System.out.println("Please choose any menu option: ");
			System.out.println("1. Create Student");
			System.out.println("2. List Student");
			System.out.println("3. Update Student");
			System.out.println("4. View Student");
			System.out.println("5. Delete Student");
			System.out.println("6. Search Student");
			System.out.println("7. Logout Student");
			
			int option=scanner.nextInt();
			switch(option) {
			case 1:
				studentService.createStudent();
				break;
			case 2:
				studentService.listStudent();
				break;
			case 3:
				studentService.updateStudent();
				break;
			case 4:
				studentService.viewStudent();
				break;
			case 5:
				studentService.deleteStudent();
				break;
			case 6:
				studentService.searchStudent();
				break;
			case 7:
				logout();
				break;
			default:
				System.out.println("Please Select valid option!");
			
			}
		}
		
	}
	public static void introduction() {
		System.out.println("Welcome to Student Management System!");
	}
	public static void logout() {
		System.out.println("Thank You, Visit Again!");
	}

}
